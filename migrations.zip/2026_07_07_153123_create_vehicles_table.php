<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('vehicles', function (Blueprint $table) {

            $table->id();

            $table->foreignId('driver_id')
                ->constrained()
                ->cascadeOnUpdate()
                ->cascadeOnDelete();

            $table->string('plate_number')->unique();

            // Optional fields (not present on POSO ticket)
            $table->string('vehicle_type')->nullable();

            $table->string('brand')->nullable();

            $table->string('model')->nullable();

            $table->string('color')->nullable();

            $table->string('engine_number')->nullable();

            $table->string('chassis_number')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('vehicles');
    }
};